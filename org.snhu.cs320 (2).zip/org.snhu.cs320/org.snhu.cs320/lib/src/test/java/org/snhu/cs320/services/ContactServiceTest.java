package org.snhu.cs320.services;

import static org.assertj.core.api.Assertions.assertThat;

import static org.junit.jupiter.api.Assertions.assertThrows;
import java.util.Map;
import org.junit.jupiter.api.BeforeEach;
import org.junit.jupiter.api.Test;
import org.junit.jupiter.params.ParameterizedTest;
import org.junit.jupiter.params.provider.ValueSource;
import org.snhu.cs320.entities.Contact;
import jakarta.validation.ValidationException;

public class ContactServiceTest {
	
	ContactService service;
	
	@BeforeEach
	void init() {
		ContactService.INSTANCE = null;
		service = ContactService.getInstance();
		service.entityRepository.putAll(Map.of(
                "9999888800", new Contact( "9999888800", "Rick", "James", "1234567890", "13 Charles Street"),
                "9999888801", new Contact( "9999888801", "Tyler", "Jacobs", "1234647890", "23 Dragon Lane"),
                "9999888802", new Contact( "9999888802", "Arianna", "Swift", "1288567890", "1449 Lousy Avenue"),
                "9999888803", new Contact( "9999888803", "Nelly", "Todd", "1234585890", "8054 Stopheim Court")
	));
	}
	
	
	@Test
	public void create_PreventsAddingExistingContact() {
		assertThrows(
				NullPointerException.class,
				() -> service.create(null)
		);
		assertThrows(
				IllegalArgumentException.class,
				() -> service.create(new Contact( "9999888800", "Rick", "James", "1234567890", "13 Charles Street"))
		);
	}
	
	@Test
	public void create_Successful() {
		service.create(new Contact("1234567890", "Kai", "Glass", "1234567890", "1445 Great Oaks"));
		assertThat(service.entityRepository).containsKey("1234567890");
	}
	
	@Test
	public void create_InvalidEntityBlocked() {
		assertThrows(ValidationException.class, () -> service.create(new Contact("", "", "", "","")));
	}
	
	@Test
	public void deleteById_IdExists() {
		assertThat(service.deleteById("9999888800"))
			.isNotEmpty()
			.get()
			.extracting(p -> p.contactID())
			.isEqualTo("9999888800");
		
		assertThat(service.entityRepository)
			.doesNotContainKey("9999888800");
	}
	
	@Test
	public void deleteById_IdDoesNotExist() {
		assertThat(service.deleteById("abcd"))
			.isEmpty();
	}
	
	@ParameterizedTest
	@ValueSource(strings = {
		"     ",
		"\n\n\r\r",
		""
	})
	public void deleteById_InvalidId(final String value) {
		assertThrows(IllegalArgumentException.class, () -> service.deleteById(value));
	}
	
	@Test
	public void deleteById_NullId() {
		assertThrows(IllegalArgumentException.class, () -> service.deleteById(null));
	}
	
	@Test
	public void update_Successful() {
		assertThat(service.entityRepository.containsKey("9999888800"));
		service.entityRepository.replace("9999888800",service.entityRepository.get("9999888800") , new Contact("9999888800","John","Ham","1234567889","445 Lake Way"));
		service.update(service.entityRepository.get("9999888800"));
		assertThat(service.entityRepository)
		.containsEntry("9999888800", new Contact("9999888800","John","Ham","1234567889","445 Lake Way"));	
	}
	
	@Test
	public void update_IdNotFound() {
		service.update(new Contact("1234567890", "Kai", "Glass", "1234567890", "1445 Great Oaks"));
		assertThat(service.entityRepository)
		.doesNotContainEntry("9999888800", new Contact("1234567890", "Kai", "Glass", "1234567890", "1445 Great Oaks"));
	}
	
	@Test
	public void update_InvalidEntityBlocked() {
		assertThrows(ValidationException.class, () -> service.update(new Contact("","","","","")));
	}
	
	@Test
	public void findById_IdExists() {
		assertThat(service.findById("9999888800"))
			.isNotEmpty()
			.get()
			.extracting(p -> p.contactID())
			.isEqualTo("9999888800");
		
		assertThat(service.entityRepository)
			.containsKey("9999888800");
	}
	
	@Test
	public void findById_IdDoesNotExist() {
		assertThat(service.findById("abcd"))
			.isEmpty();
	}
	
	@ParameterizedTest
	@ValueSource(strings = {
		"     ",
		"\n\n\r\r",
		""
	})
	public void findById_InvalidId(final String value) {
		assertThrows(IllegalArgumentException.class, () -> service.findById(value));
	}
	
	@Test
	public void findById_NullId() {
		assertThrows(IllegalArgumentException.class, () -> service.findById(null));
	}

	@ParameterizedTest
	@ValueSource(strings = {
		"     ",
		"\n\n\r\r",
		""
	})
	public void checkFirstName_InavalidFirstName(final String value) {
		assertThrows(IllegalArgumentException.class, () -> service.checkFirstName(value));
	}
	
	@Test
	public void checkFirstName_NullFirstName() {
		assertThrows(IllegalArgumentException.class, () -> service.checkFirstName(null));
	}
	
	@ParameterizedTest
	@ValueSource(strings = {
		"     ",
		"\n\n\r\r",
		""
	})
	public void checkLastName_InavalidLastName(final String value) {
		assertThrows(IllegalArgumentException.class, () -> service.checkLastName(value));
	}
	
	@Test
	public void checkLastName_NullLastName() {
		assertThrows(IllegalArgumentException.class, () -> service.checkLastName(null));
	}
	
	@ParameterizedTest
	@ValueSource(strings = {
		"     ",
		"\n\n\r\r",
		""
	})
	public void checkPhone_InavalidPhone(final String value) {
		assertThrows(IllegalArgumentException.class, () -> service.checkPhone(value));
	}
	
	@Test
	public void checkPhone_NullPhone() {
		assertThrows(IllegalArgumentException.class, () -> service.checkPhone(null));
	}
	
	@ParameterizedTest
	@ValueSource(strings = {
		"     ",
		"\n\n\r\r",
		""
	})
	public void checkAddress_InavalidAddress(final String value) {
		assertThrows(IllegalArgumentException.class, () -> service.checkAddress(value));
	}
	
	@Test
	public void checkAddress_NullAddress() {
		assertThrows(IllegalArgumentException.class, () -> service.checkAddress(null));
	}
}

