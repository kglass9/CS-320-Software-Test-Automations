package org.snhu.cs320.entities;

import jakarta.validation.constraints.NotBlank;
import jakarta.validation.constraints.Pattern;
import jakarta.validation.constraints.Size;

public record Contact(
		@NotBlank(message = "ContactID is a required field")
		@Size(max = 10, message = "ContactId cannot be longer than (max) characters)")
		String contactID,
		
		@NotBlank(message = "FirstName is a required field")
		@Size(max = 10, message = "FirstName cannot be longer than (max) characters)")
		String firstName,
		
		@NotBlank(message = "LastName is a required field")
		@Size(max = 10, message = "LastName cannot be longer than (max) characters)")
		String lastName,
		
		@NotBlank(message = "Phone is a required field")
		@Pattern(regexp = "\\d{10}", message = "Phone must be excatly 10 digits")
		String contactPhone,
		
		@NotBlank(message = "Address is a required field")
		@Size(max = 30, message = "Address cannot be longer than (max) characters)")
		String contactAddress
) {

}
