package org.snhu.cs320.services;

import java.util.Map;
import java.util.Objects;
import java.util.Optional;
import java.util.concurrent.ConcurrentHashMap;

import org.snhu.cs320.entities.Contact;
import org.snhu.cs320.validations.EntityValidator;

public class ContactService {
	
	static ContactService INSTANCE;
	
	final Map<String, Contact> entityRepository;
	final EntityValidator validator;
	
	private ContactService() {
		entityRepository = new ConcurrentHashMap<>();
		this.validator = new EntityValidator();
	}
	
	public static synchronized ContactService getInstance() {
		if(INSTANCE == null) {
			INSTANCE = new ContactService();
		}
		return INSTANCE;
	}
	
	public Contact create(final Contact Contact) {
		Objects.requireNonNull(Contact);
		
		return validator.validateAndDoOrThrow(
				Contact,
				p -> {
					if(entityRepository.containsKey(Contact.contactID())) {
						throw new IllegalArgumentException(String.format("An entry with ID [%s] already exists. Did you mean to update)", Contact.contactID()));
					}
					return entityRepository.put(Contact.contactID(), Contact);
				}
		);
	}
	
	public Optional<Contact> deleteById(final String id) {
		checkId(id);
		return Optional.ofNullable(entityRepository.remove(id));
	}
	
	public  Optional<Contact> findById(final String id) {
		checkId(id);
		return Optional.ofNullable(entityRepository.get(id));
	}

	public Contact update(final Contact Contact) {
		Objects.requireNonNull(Contact);
		
		return validator.validateAndDoOrThrow(
				Contact,
				p -> {
					if(entityRepository.containsKey(Contact.contactID())) {
						checkFirstName(Contact.firstName());
						checkLastName(Contact.lastName());
						checkPhone(Contact.contactPhone());
						checkAddress(Contact.contactAddress());
						entityRepository.put(Contact.contactID(), Contact);
					}
					return Contact;
				}
		);
	}
	
	private static void checkId(final String id) {
		if(id == null || id.trim().length() < 1) {
			throw new IllegalArgumentException("ID is a required argument");
		}
	}
	
	void checkFirstName(final String firstName) {
		if(firstName == null || firstName.trim().length() < 1) {
			throw new IllegalArgumentException("FistName is a required argument");
		}
	}
	
	void checkLastName(final String lastName) {
		if(lastName == null || lastName.trim().length() < 1) {
			throw new IllegalArgumentException("LastName is a required argument");
		}
	}
	
	void checkPhone(final String phone) {
		if(phone == null || phone.length() != 10) {
			throw new IllegalArgumentException("Phone is a required argument");
		}
	}
	
    void checkAddress(final String address) {
		if(address == null || address.trim().length() < 1) {
			throw new IllegalArgumentException("Address is a required argument");
		}
	}
}
